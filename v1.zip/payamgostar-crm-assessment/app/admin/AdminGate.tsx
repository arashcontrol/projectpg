"use client";

import { useEffect, useState } from "react";
import { RefreshCcw } from "lucide-react";
import type { CmsConfig } from "../cms-config";
import AdminApp from "./AdminApp";

export default function AdminGate(){const[data,setData]=useState<{config:CmsConfig;source:string;user:{email:string;displayName:string}}|null>(null);useEffect(()=>{fetch("/api/admin/config").then(async(response)=>{if(response.status===401){window.location.href="/admin/login";return null;}return response.json();}).then((value)=>value&&setData(value));},[]);if(!data)return <main className="admin-gate-loading"><img src="/brand/payamgostar-mark.png" alt=""/><RefreshCcw/><span>در حال ورود به مرکز راهبری…</span></main>;return <AdminApp initialConfig={data.config} source={data.source} user={data.user}/>}
