import ExperienceApp from "./ExperienceApp";

export default function Home() {
  return <ExperienceApp />;
}
