import AccountApp from "./AccountApp";

export default function AccountPage(){return <AccountApp/>}
