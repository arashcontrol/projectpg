import AccountApp from "../AccountApp";

export default function AccountLoginPage(){return <AccountApp/>}
