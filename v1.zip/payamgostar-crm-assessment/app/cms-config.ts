import { faqCategories } from "./faq-data";
import { maturityAssessment } from "./maturity-data";
import { questionnaireSections } from "./questionnaire-data";

export type CmsKey =
  | "siteContent"
  | "theme"
  | "levels"
  | "maturity"
  | "questionnaire"
  | "faq"
  | "modules"
  | "recommendationMatrix"
  | "maturityRoutes"
  | "outputTemplates"
  | "industries"
  | "clubSettings"
  | "agentSettings";

export const defaultSiteContent = {
  brandName: "پیام‌گستر",
  productName: "سامانه ارزیابی هوشمند مشتریان",
  eyebrow: "AI Assessment Platform",
  heroTitle: "از شناخت نیاز تا نقشه اجرای CRM؛ در یک مسیر هوشمند.",
  heroDescription: "با ارزیابی بلوغ سازمانی شروع کنید و متناسب با هدف، عمق و مرحله تصمیم‌گیری خود به یک پیشنهاد دقیق‌تر برسید.",
  primaryCta: "شروع ارزیابی رایگان",
  secondaryCta: "مشاهده شبیه‌سازی نتیجه",
  phone: "۰۲۱-۴۹۱۱۶",
  trustLine: "خروجی قابل استفاده برای فروش، طراحی راهکار و استقرار",
  proposalTitle: "پروپوزال ویژه سازمان خود را دریافت کنید.",
  proposalDescription: "نتیجه ارزیابی برای کارشناس ارشد پیام‌گستر آماده می‌شود تا نسخه، ماژول‌ها و مسیر اجرای متناسب با سازمان شما پیشنهاد شود.",
};

export const defaultTheme = {
  primary: "#ff6b21",
  primarySoft: "#fff0e8",
  navy: "#182842",
  navySoft: "#40516a",
  aqua: "#25c2d3",
  canvas: "#f7f6fc",
  surface: "#ffffff",
  fontFamily: "Yekan Bakh",
  radius: 24,
};

export const defaultLevels = [
  { level: 0, tag: "توصیه‌شده · مقدماتی", title: "ارزیابی بلوغ سازمانی", description: "در کمتر از ۷ دقیقه، وضعیت فروش، بازاریابی، فرایندها، داده و تجربه مشتری را بسنجید و اولویت بهبود خود را پیدا کنید.", time: "کمتر از ۷ دقیقه", output: "امتیاز بلوغ، وضعیت سازمان و راهکار اولویت‌دار", accent: "orange" },
  { level: 1, tag: "شناخت سریع", title: "ارزیابی اولیه", description: "نیازهای اصلی برای آماده‌سازی پیشنهاد اولیه؛ مناسب مدیر یا کارشناس فروش پیش از جلسه پرزنت.", time: "از ۱۲ دقیقه", output: "نسخه پیشنهادی، ماژول‌ها و پروپوزال اولیه", accent: "mint" },
  { level: 2, tag: "نیازسنجی تفصیلی", title: "طراحی راهکار", description: "شرح جزئیات واحدها، داده‌ها و فرایندها برای طراحی سناریو و برنامه استقرار.", time: "از ۲۵ دقیقه", output: "طرح راهکار، برآورد استقرار و اقدامات اجرایی", accent: "blue" },
  { level: 3, tag: "پرونده کامل پروژه", title: "آماده‌سازی استقرار", description: "تعیین دامنه، حجم، ریسک‌ها و جزئیات اجرایی برای تحویل مستقیم به تیم استقرار.", time: "از ۴۵ دقیقه", output: "گذرنامه پروژه، ریسک‌ها و نقشه ۳۰/۶۰/۹۰ روزه", accent: "violet" },
] as const;

export const defaultModules = [
  { id: "crm-core", name: "کنسول مدیریت ارتباط با مشتری", plan: 1, solution: "اتوماسیون فروش", keys: ["پرونده", "سوابق مشتری", "بانک اطلاعاتی", "CRM"], reason: "پرونده یکپارچه و دید ۳۶۰ درجه از مشتری" },
  { id: "opportunities", name: "مدیریت فرصت‌ها", plan: 1, solution: "اتوماسیون فروش", keys: ["فرصت", "سرنخ", "قیف", "کانبان"], reason: "مدیریت سرنخ و فرصت در مراحل فروش" },
  { id: "sales", name: "مدیریت فروش", plan: 1, solution: "اتوماسیون فروش", keys: ["فروش", "پیش فاکتور", "فاکتور", "لیست قیمت"], reason: "سامان‌دهی عملیات فروش و گزارش عملکرد" },
  { id: "messaging", name: "پیام کوتاه و ایمیل هوشمند", plan: 1, solution: "اتوماسیون بازاریابی", keys: ["پیامک", "ایمیل", "واتس", "تلگرام"], reason: "ارتباط هدفمند و ثبت سوابق پیام" },
  { id: "campaigns", name: "مدیریت کمپین‌های تبلیغاتی", plan: 1, solution: "اتوماسیون بازاریابی", keys: ["کمپین", "بازاریابی", "مارکتینگ", "تبلیغ"], reason: "طراحی و سنجش کمپین و اتصال آن به فروش" },
  { id: "ticketing", name: "مدیریت درخواست‌های مشتری (Ticketing)", plan: 2, solution: "خدمات پس از فروش", keys: ["تیکت", "درخواست", "شکایت", "خدمات پس از فروش", "پشتیبانی"], reason: "ثبت، ارجاع و رهگیری درخواست مشتری" },
  { id: "contracts", name: "مدیریت قراردادها", plan: 2, solution: "خدمات پس از فروش", keys: ["قرارداد", "تمدید", "SLA"], reason: "کنترل قرارداد، سررسید و تعهدات خدمت" },
  { id: "bpms", name: "مدیریت چرخه‌های کاری BPMS+", plan: 2, solution: "BPMS و فرم‌ساز", keys: ["فرایند", "گردش کار", "کارتابل", "اتوماسیون"], reason: "مکانیزه‌کردن گردش‌کار و کنترل مراحل" },
  { id: "forms", name: "فرم‌ساز", plan: 2, solution: "BPMS و فرم‌ساز", keys: ["فرم", "نظرسنجی"], reason: "ساخت فرم‌های اختصاصی سازمان" },
  { id: "loyalty", name: "باشگاه مشتریان", plan: 2, solution: "خدمات پس از فروش", keys: ["باشگاه", "وفاداری", "پرتال مشتری"], reason: "تعامل مستمر و برنامه‌های وفاداری" },
  { id: "scoring", name: "امتیازدهی و کلاس‌بندی مشتریان", plan: 2, solution: "اتوماسیون فروش", keys: ["امتیاز", "کلاس بندی", "بخش‌بندی"], reason: "طبقه‌بندی مشتریان و سیاست‌های تشویقی" },
  { id: "reports", name: "گزارش‌ساز پیشرفته", plan: 2, solution: "داده و گزارش", keys: ["گزارش", "داشبورد", "هوش تجاری", "BI"], reason: "گزارش مدیریتی و تحلیل عملکرد" },
  { id: "mobile", name: "اپلیکیشن موبایل پیام‌گستر", plan: 3, solution: "اتوماسیون فروش", keys: ["موبایل", "خارج از سازمان", "دورکاری"], reason: "دسترسی کاربران سیار به CRM" },
  { id: "call-center", name: "داشبورد مرکز تماس", plan: 3, solution: "اتوماسیون فروش", keys: ["مرکز تماس", "VoIP", "سانترال", "تماس"], reason: "یکپارچگی تماس و گزارش مرکز تماس" },
  { id: "integration", name: "هاب یکپارچه‌سازی پیام‌گستر", plan: 3, solution: "BPMS و فرم‌ساز", keys: ["یکپارچه", "API", "وب سرویس", "مالی", "ERP"], reason: "اتصال امن CRM به سامانه‌های موجود" },
] as const;

export const defaultRecommendationMatrix = [
  { id: "sales-critical", source: "maturity-topic", condition: "اتوماسیون فروش", minWeight: 3, moduleIds: ["crm-core", "opportunities", "sales"], priority: 100 },
  { id: "marketing-critical", source: "maturity-topic", condition: "اتوماسیون بازاریابی", minWeight: 3, moduleIds: ["messaging", "campaigns"], priority: 90 },
  { id: "service-critical", source: "maturity-topic", condition: "خدمات پس از فروش", minWeight: 3, moduleIds: ["ticketing", "contracts", "loyalty"], priority: 80 },
  { id: "process-critical", source: "maturity-topic", condition: "BPMS", minWeight: 3, moduleIds: ["bpms", "forms", "integration"], priority: 70 },
  { id: "keyword-report", source: "answer-keyword", condition: "گزارش|داشبورد|BI", minWeight: 1, moduleIds: ["reports"], priority: 60 },
] as const;

export const defaultMaturityRoutes = [
  {
    id: "critical",
    min: 0,
    max: 24,
    suggestedLevel: 1,
    headline: "ابتدا زیرساخت مدیریت را یکپارچه کنید",
    interpretation: "وابستگی بالا به افراد، فایل‌های پراکنده و پیگیری دستی باعث می‌شود رشد سازمان قابل پیش‌بینی و قابل کنترل نباشد.",
    actions: ["تعریف مالک داده و مسئول هر فرایند", "ایجاد مرجع واحد برای اطلاعات مشتریان", "مستندسازی حداقل فرایندهای فروش و خدمت"],
  },
  {
    id: "organizing",
    min: 25,
    max: 49,
    suggestedLevel: 1,
    headline: "سازمان در آستانه استانداردسازی است",
    interpretation: "بخشی از رویه‌ها شکل گرفته‌اند، اما اجرای آن‌ها هنوز یکنواخت نیست و داده‌ها برای تصمیم‌گیری مدیریتی کافی نیستند.",
    actions: ["استانداردکردن مراحل و مسئولیت‌ها", "تعریف شاخص‌های پایه عملکرد", "کاهش فایل‌ها و ابزارهای پراکنده"],
  },
  {
    id: "improving",
    min: 50,
    max: 74,
    suggestedLevel: 2,
    headline: "تمرکز بعدی باید بر اتصال و اندازه‌گیری باشد",
    interpretation: "فرایندهای اصلی قابل تشخیص‌اند؛ ارزش بعدی از یکپارچگی داده، حذف گسست‌های بین‌واحدی و تحلیل منظم عملکرد ایجاد می‌شود.",
    actions: ["اتصال فرایندهای بین‌واحدی", "ساخت داشبوردهای تصمیم‌ساز", "تعریف چرخه بهبود مستمر"],
  },
  {
    id: "mature",
    min: 75,
    max: 100,
    suggestedLevel: 3,
    headline: "آماده ورود به بهینه‌سازی پیشرفته هستید",
    interpretation: "سازمان از پایه‌های مناسبی برخوردار است و می‌تواند روی پیش‌بینی، اتوماسیون عمیق و مقیاس‌پذیری تمرکز کند.",
    actions: ["بهینه‌سازی تجربه سرتاسری مشتری", "پیش‌بینی و تصمیم‌گیری داده‌محور", "طراحی نقشه مقیاس‌پذیری سازمان"],
  },
];

export const defaultOutputTemplates = [
  { level: 0, title: "گزارش بلوغ سازمانی", summary: "امتیاز، سطح بلوغ، تفسیر مدیریتی و گام‌های بهبود سازمان", primaryAction: "انتخاب ارزیابی دقیق‌تر", proposalLabel: "", proposalUrl: "", enabled: true },
  { level: 1, title: "پیشنهاد اولیه CRM", summary: "نسخه پیشنهادی، قابلیت‌ها، ماژول‌های متناسب و پروپوزال اولیه", primaryAction: "دریافت پروپوزال اختصاصی", proposalLabel: "دریافت پروپوزال", proposalUrl: "#", enabled: true },
  { level: 2, title: "طرح راهکار و استقرار", summary: "سناریوی راهکار، برآورد استقرار، اقدامات اجرایی و پروپوزال تفصیلی", primaryAction: "دریافت طرح راهکار", proposalLabel: "دریافت طرح راهکار", proposalUrl: "#", enabled: true },
  { level: 3, title: "گذرنامه کامل پروژه", summary: "دامنه، ریسک، برنامه استقرار، نقشه ۳۰/۶۰/۹۰ روزه و پروپوزال نهایی", primaryAction: "دریافت گذرنامه پروژه", proposalLabel: "دریافت خروجی کامل", proposalUrl: "#", enabled: true },
];

export const defaultIndustries = [
  "تولید و صنعت", "بازرگانی و پخش", "خدمات حرفه‌ای", "فناوری اطلاعات و نرم‌افزار", "ساختمان و عمران",
  "خودرو و قطعات", "غذا و صنایع غذایی", "دارو و تجهیزات پزشکی", "سلامت و درمان", "آموزش",
  "مالی، بیمه و سرمایه‌گذاری", "حمل‌ونقل و لجستیک", "گردشگری و مهمان‌داری", "خرده‌فروشی و فروشگاه زنجیره‌ای",
  "نفت، گاز و پتروشیمی", "کشاورزی و دامپروری", "رسانه و تبلیغات", "دولتی و عمومی", "سایر",
];

export const defaultClubSettings = {
  enabled: true,
  title: "پنل ارزیابی و کلاب مدیران",
  welcomeText: "گزارش‌ها، روند پیشرفت و جایگاه سازمان خود را در یک نمای یکپارچه دنبال کنید.",
  benchmarkEnabled: true,
  benchmarkMinimumSample: 5,
  showPercentile: true,
  sections: { reports: true, benchmark: true, recommendedAssessments: true, profile: true },
};

export const defaultAgentSettings = {
  enabled: false,
  mode: "faq-retrieval",
  provider: "future-provider",
  endpointLabel: "اتصال تنظیم نشده",
  model: "",
  systemInstruction: "فقط براساس دانش تاییدشده پیام‌گستر پاسخ بده و برای پیشنهاد تجاری کاربر را به ارزیابی هدایت کن.",
  permissions: { readFaq: true, readAssessment: true, suggestModules: true, writeCms: false },
};

export type CmsConfig = {
  siteContent: typeof defaultSiteContent;
  theme: typeof defaultTheme;
  levels: typeof defaultLevels;
  maturity: typeof maturityAssessment;
  questionnaire: typeof questionnaireSections;
  faq: typeof faqCategories;
  modules: typeof defaultModules;
  recommendationMatrix: typeof defaultRecommendationMatrix;
  maturityRoutes: typeof defaultMaturityRoutes;
  outputTemplates: typeof defaultOutputTemplates;
  industries: typeof defaultIndustries;
  clubSettings: typeof defaultClubSettings;
  agentSettings: typeof defaultAgentSettings;
};

export const defaultCmsConfig: CmsConfig = {
  siteContent: defaultSiteContent,
  theme: defaultTheme,
  levels: defaultLevels,
  maturity: maturityAssessment,
  questionnaire: questionnaireSections,
  faq: faqCategories,
  modules: defaultModules,
  recommendationMatrix: defaultRecommendationMatrix,
  maturityRoutes: defaultMaturityRoutes,
  outputTemplates: defaultOutputTemplates,
  industries: defaultIndustries,
  clubSettings: defaultClubSettings,
  agentSettings: defaultAgentSettings,
};
