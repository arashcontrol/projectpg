import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "سامانه ارزیابی هوشمند پیام‌گستر | بلوغ سازمانی و نیازسنجی CRM",
  description: "پلتفرم چهارسطحی ارزیابی بلوغ سازمانی، نیازسنجی CRM، پیشنهاد ماژول و آماده‌سازی استقرار پیام‌گستر",
  other: { "codex-preview": "development" },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="fa" dir="rtl"><body>{children}</body></html>;
}
