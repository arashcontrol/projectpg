"use client";

/* eslint-disable react-hooks/set-state-in-effect */
import { useEffect, useRef, useState } from "react";
import { questionnaireSections, Question, Section } from "./questionnaire-data";
import type { CmsConfig } from "./cms-config";

type Level = 1 | 2 | 3;
type View = "landing" | "scope" | "wizard" | "account" | "result";
type Answer = string | number | string[];
type Answers = Record<string, Answer>;

const DRAFT_KEY = "payamgostar-assessment-v1";
const fa = new Intl.NumberFormat("fa-IR");
const coreSections = [1, 2, 11];

const levels: Array<{ level: Level; tag: string; title: string; description: string; time: string; output: string; tone: string }> = [
  { level: 1, tag: "شناخت سریع", title: "ارزیابی اولیه", description: "شناخت نیاز اصلی و آماده‌سازی پیشنهاد اولیه؛ مناسب مشتری یا کارشناس فروش پیش از جلسه پرزنت.", time: "از ۱۲ دقیقه", output: "نسخه پیشنهادی، ماژول‌ها و پروپوزال اولیه", tone: "mint" },
  { level: 2, tag: "نیازسنجی تفصیلی", title: "طراحی راهکار", description: "شرح نحوه اجرای نیازها، جزئیات واحدها، داده‌ها و فرایندها برای تیم راهکار و استقرار.", time: "از ۲۵ دقیقه", output: "طرح راهکار، برآورد استقرار و اقدامات اجرایی", tone: "blue" },
  { level: 3, tag: "پرونده کامل پروژه", title: "آماده‌سازی استقرار", description: "تعیین دامنه، حجم، ریسک‌ها و جزئیات اجرایی پیش از شروع پروژه و تحویل به تیم استقرار.", time: "از ۴۵ دقیقه", output: "گذرنامه پروژه، ریسک‌ها و نقشه ۳۰/۶۰/۹۰ روزه", tone: "amber" },
];

const modules = [
  { name: "کنسول مدیریت ارتباط با مشتری", plan: 1, keys: ["پرونده", "سوابق مشتری", "بانک اطلاعاتی", "CRM"], reason: "پرونده یکپارچه و دید ۳۶۰ درجه از مشتری" },
  { name: "مدیریت فرصت‌ها", plan: 1, keys: ["فرصت", "سرنخ", "قیف", "کانبان"], reason: "مدیریت سرنخ و فرصت در مراحل فروش" },
  { name: "مدیریت فروش", plan: 1, keys: ["فروش", "پیش فاکتور", "فاکتور", "لیست قیمت"], reason: "سامان‌دهی عملیات فروش و گزارش عملکرد" },
  { name: "پیام کوتاه و ایمیل هوشمند", plan: 1, keys: ["پیامک", "ایمیل", "واتس", "تلگرام"], reason: "ارتباط هدفمند و ثبت سوابق پیام" },
  { name: "مدیریت کمپین‌های تبلیغاتی", plan: 1, keys: ["کمپین", "بازاریابی", "مارکتینگ", "تبلیغ"], reason: "طراحی و سنجش کمپین و اتصال آن به فروش" },
  { name: "انبارداری", plan: 2, keys: ["انبار", "موجودی", "کالا"], reason: "مدیریت موجودی و گردش کالا" },
  { name: "مدیریت درخواست‌های مشتری (Ticketing)", plan: 2, keys: ["تیکت", "درخواست", "شکایت", "خدمات پس از فروش", "پشتیبانی"], reason: "ثبت، ارجاع و رهگیری درخواست مشتری" },
  { name: "مدیریت قراردادها", plan: 2, keys: ["قرارداد", "تمدید", "SLA"], reason: "کنترل قرارداد، سررسید و تعهدات خدمت" },
  { name: "فرم‌ساز", plan: 2, keys: ["فرم", "نظرسنجی"], reason: "ساخت فرم‌های اختصاصی سازمان" },
  { name: "مدیریت چرخه‌های کاری BPMS+", plan: 2, keys: ["فرایند", "گردش کار", "کارتابل", "اتوماسیون"], reason: "مکانیزه‌کردن گردش‌کار و کنترل مراحل" },
  { name: "باشگاه مشتریان", plan: 2, keys: ["باشگاه", "وفاداری", "پرتال مشتری"], reason: "تعامل مستمر و برنامه‌های وفاداری" },
  { name: "سیستم امتیازدهی و کلاس‌بندی مشتریان", plan: 2, keys: ["امتیاز", "کلاس بندی", "بخش‌بندی"], reason: "طبقه‌بندی مشتریان و سیاست‌های تشویقی" },
  { name: "گزارش‌ساز پیشرفته", plan: 2, keys: ["گزارش", "داشبورد", "هوش تجاری", "BI"], reason: "گزارش مدیریتی و تحلیل عملکرد" },
  { name: "اپلیکیشن موبایل پیام‌گستر", plan: 3, keys: ["موبایل", "خارج از سازمان", "دورکاری"], reason: "دسترسی کاربران سیار به CRM" },
  { name: "داشبورد مرکز تماس پیام‌گستر", plan: 3, keys: ["مرکز تماس", "VoIP", "سانترال", "تماس"], reason: "یکپارچگی تماس و گزارش مرکز تماس" },
  { name: "یکپارچگی با سیستم‌های مالی", plan: 3, keys: ["مالی", "حسابداری", "سپیدار", "پیوست", "تدبیر", "یکپارچگی"], reason: "همگام‌سازی داده‌های مالی و مشتری" },
  { name: "تخصیص داده پیشرفته", plan: 3, keys: ["دیتابیس", "پایگاه داده", "تخصیص داده"], reason: "تبادل پیشرفته داده میان سامانه‌ها" },
  { name: "اتوماسیون جذب (ATS)", plan: 3, keys: ["استخدام", "جذب", "ATS", "منابع انسانی"], reason: "مدیریت فرایند جذب و متقاضیان" },
];

const sectionHints: Record<number, string[]> = { 5: ["یکپارچگی", "گزارش"], 6: ["فروش", "فرصت"], 7: ["خدمات پس از فروش", "تیکت", "قرارداد", "تماس"], 8: ["باشگاه", "امتیاز"], 9: ["کمپین", "پیامک", "ایمیل"], 10: ["فرم", "فرایند"] };

function optionsOf(q: Question) {
  if (!q.rules || !/(آبشاری|چک‌باکس|دوحالتی|مقیاس)/.test(q.type)) return [];
  return q.rules.replace(/\s*—\s*حداکثر.*$/, "").split(/\s*\/\s*/).map(x => x.trim()).filter(Boolean);
}
function answered(v: Answer | undefined) { return Array.isArray(v) ? v.length > 0 : v !== undefined && String(v).trim() !== ""; }
function asText(v: Answer | undefined) { return Array.isArray(v) ? v.join(" | ") : String(v ?? ""); }

function Brand() { return <div className="brand"><span className="brand-mark"><i /><i /><i /></span><b>پیام‌گستر</b><small>ارزیابی هوشمند CRM</small></div>; }
function Header({ home, saving = false }: { home?: () => void; saving?: boolean }) {
  return <header className="topbar"><button onClick={home} aria-label="صفحه نخست"><Brand /></button><div>{saving && <span className="saving"><i /> ذخیره خودکار</span>}<a href="tel:02149714">۰۲۱-۴۹۷۱۴</a></div></header>;
}

function Landing({ select, sample, hasDraft, resume }: { select: (l: Level) => void; sample: () => void; hasDraft: boolean; resume: () => void }) {
  return <main className="landing"><Header />
    <section className="hero shell"><div className="hero-copy"><span className="pill">سامانه ارزیابی پیش از خرید و استقرار</span><h1>قبل از انتخاب CRM،<br /><em>مسیر درست را پیدا کنید.</em></h1><p>با پاسخ به پرسش‌های ساختاریافته، نیازهای سازمان شما به نسخه مناسب پیام‌گستر، ماژول‌های پیشنهادی و نقشه اقدام قابل اجرا تبدیل می‌شود.</p><div className="benefits"><span>بدون نیاز به دانش فنی</span><span>خروجی اختصاصی سازمان</span><span>ذخیره خودکار پیش‌نویس</span></div>{hasDraft && <button className="resume" onClick={resume}><b>ادامه ارزیابی ذخیره‌شده</b><small>از همان جایی که متوقف شدید</small><span>ادامه ←</span></button>}</div>
      <div className="hero-art"><div className="mock"><small>خروجی ارزیابی</small><div className="mock-score"><b>۷۸</b><span>امتیاز آمادگی</span></div><p><span>نسخه پیشنهادی</span><b>ابری حرفه‌ای</b></p><p><span>زمان راه‌اندازی</span><b>۷ تا ۱۰ هفته</b></p></div><i className="float a">✓ دامنه پروژه روشن</i><i className="float b">۴ ماژول اولویت‌دار</i></div></section>
    <section className="levels shell"><div className="section-head"><div><span>انتخاب عمق ارزیابی</span><h2>ارزیابی مناسب مرحله خود را انتخاب کنید</h2></div><p>زمان واقعی پس از انتخاب حوزه‌های مرتبط محاسبه می‌شود. هر سطح، خروجی سطح قبل را کامل‌تر می‌کند.</p></div><div className="level-grid">{levels.map(x => <article key={x.level} className={x.tone}><div className="level-top"><span>سطح {fa.format(x.level)}</span><b>{x.time}</b></div><strong className="big-num">۰{fa.format(x.level)}</strong><small>{x.tag}</small><h3>{x.title}</h3><p>{x.description}</p><div className="level-output"><span>آنچه دریافت می‌کنید</span><b>{x.output}</b></div><button onClick={() => select(x.level)}>شروع این ارزیابی <span>←</span></button></article>)}</div><button className="sample" onClick={sample}>ابتدا یک نمونه خروجی کامل را ببینید ←</button></section>
    <section className="ideas"><div className="shell"><div><span>سه ایده برای ارزیابی بهتر</span><h2>فرم با سازمان شما تطبیق پیدا می‌کند.</h2></div><article><b>۰۱</b><h3>دامنه هوشمند</h3><p>فقط حوزه‌های مرتبط را انتخاب کنید تا مسیر کوتاه و دقیق بماند.</p></article><article><b>۰۲</b><h3>ضریب اطمینان</h3><p>کامل‌بودن داده و اعتبار پیشنهاد در نتیجه نمایش داده می‌شود.</p></article><article><b>۰۳</b><h3>گذرنامه پروژه</h3><p>خروجی برای فروش، فنی و استقرار آماده مرور و چاپ است.</p></article></div></section>
    <footer className="footer shell"><Brand /><p>پیشنهادها براساس پاسخ‌های شما و فهرست رسمی محصولات پیام‌گستر است.</p><div><a target="_blank" href="https://www.payamgostar.com/fa/pricing/cloud">نسخه ابری</a><a target="_blank" href="https://www.payamgostar.com/fa/pricing/standard">نسخه استاندارد</a></div></footer>
  </main>;
}

function ScopeCard({ section, level, active, locked, click }: { section: Section; level: Level; active: boolean; locked?: boolean; click: () => void }) {
  const count = section.questions.filter(q => q.level <= level).length;
  return <button className={`scope-card ${active ? "active" : ""}`} onClick={click}><i>{locked ? "●" : active ? "✓" : ""}</i><em>{String(section.id).padStart(2, "0")}</em><b>{section.title}</b><span>{section.description}</span><small>{fa.format(count)} سؤال</small></button>;
}
function Scope({ sectionsSource, level, selected, setSelected, mode, setMode, back, start }: { sectionsSource: Section[]; level: Level; selected: number[]; setSelected: (v: number[]) => void; mode: string; setMode: (v: "customer" | "expert") => void; back: () => void; start: () => void }) {
  const count = sectionsSource.filter(s => selected.includes(s.id)).reduce((n, s) => n + s.questions.filter(q => q.level <= level).length, 0);
  const minutes = Math.max(8, Math.round(count * (level === 1 ? .32 : level === 2 ? .47 : .68)));
  const toggle = (s: Section) => !s.core && setSelected(selected.includes(s.id) ? selected.filter(id => id !== s.id) : [...selected, s.id]);
  return <main className="scope-page"><Header home={back} saving /><div className="scope-shell"><button className="back" onClick={back}>→ بازگشت به انتخاب سطح</button><div className="scope-head"><div><span>تنظیم دامنه ارزیابی سطح {fa.format(level)}</span><h1>کدام حوزه‌ها در پروژه شما مطرح‌اند؟</h1><p>سه بخش پایه همیشه فعال هستند. حوزه‌های تخصصی مرتبط را انتخاب کنید تا پرسش‌های غیرضروری وارد مسیر نشوند.</p></div><aside><b>{fa.format(count)}</b><span>سؤال در دامنه</span><small>حدود {fa.format(minutes)} دقیقه</small></aside></div>
    <div className="mode"><span>تکمیل‌کننده فرم:</span><button className={mode === "customer" ? "active" : ""} onClick={() => setMode("customer")}><b>مشتری</b><small>پاسخ مستقیم سازمان</small></button><button className={mode === "expert" ? "active" : ""} onClick={() => setMode("expert")}><b>کارشناس پیام‌گستر</b><small>در جلسه نیازسنجی</small></button></div>
    <div className="scope-label"><h2>بخش‌های پایه</h2><span>همیشه فعال</span></div><div className="scope-grid core">{sectionsSource.filter(s => s.core).map(s => <ScopeCard key={s.id} section={s} level={level} active locked click={() => {}} />)}</div><div className="scope-label"><h2>حوزه‌های تخصصی</h2><span>یک یا چند مورد را انتخاب کنید</span></div><div className="scope-grid">{sectionsSource.filter(s => !s.core).map(s => <ScopeCard key={s.id} section={s} level={level} active={selected.includes(s.id)} click={() => toggle(s)} />)}</div><div className="scope-action"><div><b>{fa.format(selected.length)} بخش انتخاب شده</b><span>پیش‌نویس روی همین دستگاه ذخیره می‌شود.</span></div><button onClick={start}>شروع پاسخ‌گویی ←</button></div></div></main>;
}

function Field({ q, value, change, industries }: { q: Question; value: Answer | undefined; change: (v: Answer) => void; industries: string[] }) {
  const opts = optionsOf(q), multi = q.type.includes("چک‌باکس"), single = /(آبشاری|دوحالتی|مقیاس)/.test(q.type);
  const maxRaw = q.rules.match(/حداکثر\s*([۰-۹0-9]+)/)?.[1];
  const max = maxRaw ? Number(maxRaw.replace(/[۰-۹]/g, d => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))) : 0;
  if (q.id === "1.8") { const [a = "", b = ""] = String(value ?? "").split(" | "); return <div className="double"><select value={a} onChange={e => change(`${e.target.value} | ${b}`)}><option value="">انتخاب صنعت اصلی</option>{industries.map((industry)=><option key={industry} value={industry}>{industry}</option>)}</select><input value={b} onChange={e => change(`${a} | ${e.target.value}`)} placeholder="زیرصنعت یا حوزه تخصصی" /></div>; }
  if (q.id === "1.14") return <textarea rows={5} value={String(value ?? "")} onChange={e => change(e.target.value)} placeholder="برای هر مرکز: نوع، تعداد، استان و شهرهای اصلی را در یک خط بنویسید." />;
  if (multi) { const chosen = Array.isArray(value) ? value : []; return <div className="multi">{opts.map(o => <label key={o} className={chosen.includes(o) ? "checked" : ""}><input type="checkbox" checked={chosen.includes(o)} onChange={() => chosen.includes(o) ? change(chosen.filter(x => x !== o)) : (!max || chosen.length < max) && change([...chosen, o])} /><i>✓</i><span>{o}</span></label>)}{max > 0 && <small>{fa.format(chosen.length)} از حداکثر {fa.format(max)} انتخاب</small>}</div>; }
  if (single && opts.length > 7) return <select value={String(value ?? "")} onChange={e => change(e.target.value)}><option value="">انتخاب کنید</option>{opts.map(o => <option key={o}>{o}</option>)}</select>;
  if (single) return <div className={`single ${opts.length <= 2 ? "binary" : ""}`}>{opts.map((o, i) => <button key={o} className={value === o ? "active" : ""} onClick={() => change(o)}><i>{fa.format(i + 1)}</i><span>{o}</span></button>)}</div>;
  if (q.type.includes("بارگذاری")) return <label className="upload"><input type="file" onChange={e => change(e.target.files?.[0]?.name ?? "")} /><b>＋</b><span>{value ? String(value) : "فایل را انتخاب کنید"}</span><small>در نسخه نمایشی فقط نام فایل ثبت می‌شود.</small></label>;
  if (q.type.includes("متنی بلند")) return <textarea rows={6} value={String(value ?? "")} onChange={e => change(e.target.value)} placeholder="پاسخ خود را بنویسید…" />;
  if (q.type.includes("تاریخ")) return <input value={String(value ?? "")} onChange={e => change(e.target.value)} placeholder="مثال: ۱۴۰۵/۰۸/۱۵" />;
  if (/(عددی|سال)/.test(q.type)) return <input className="number" type="number" min="0" step={q.type.includes("اعشاری") ? ".1" : "1"} value={value ?? ""} onChange={e => change(e.target.value === "" ? "" : Number(e.target.value))} placeholder="عدد را وارد کنید" />;
  return <input type={q.type.includes("URL") ? "url" : "text"} value={String(value ?? "")} onChange={e => change(e.target.value)} placeholder={q.type.includes("Tag") ? "مقادیر را با ویرگول جدا کنید" : "پاسخ را وارد کنید"} />;
}

function Wizard({ sectionsSource, industries, level, selected, answers, setAnswers, back, finish }: { sectionsSource: Section[]; industries: string[]; level: Level; selected: number[]; answers: Answers; setAnswers: (v: Answers) => void; back: () => void; finish: () => void }) {
  const sections = sectionsSource.filter(s => selected.includes(s.id)).map(s => ({ ...s, questions: s.questions.filter(q => q.level <= level) })).filter(s => s.questions.length);
  const list = sections.flatMap(s => s.questions.map(q => ({ q, s })));
  const [index, setIndex] = useState(0), [error, setError] = useState("");
  const item = list[index], done = list.filter(x => answered(answers[x.q.id])).length, progress = Math.round(done / list.length * 100);
  const next = () => { if (item.q.required && !answered(answers[item.q.id])) return setError("پاسخ این سؤال برای ادامه الزامی است."); setError(""); if (index === list.length - 1) finish(); else setIndex(index + 1); window.scrollTo({ top: 0, behavior: "smooth" }); };
  const jump = (s: Section) => { const i = list.findIndex(x => x.s.id === s.id && !answered(answers[x.q.id])); setIndex(i >= 0 ? i : list.findIndex(x => x.s.id === s.id)); setError(""); };
  return <main className="wizard"><Header home={back} saving /><div className="wizard-layout"><aside><div className="aside-top"><span>سطح {fa.format(level)}</span><b>{fa.format(done)} از {fa.format(list.length)}</b></div><div className="progress"><i style={{ width: `${progress}%` }} /></div><small>{fa.format(progress)}٪ تکمیل شده</small><nav>{sections.map((s, i) => { const n = s.questions.filter(q => answered(answers[q.id])).length; return <button key={s.id} className={s.id === item.s.id ? "active" : ""} onClick={() => jump(s)}><i>{n === s.questions.length ? "✓" : fa.format(i + 1)}</i><span><b>{s.title}</b><small>{fa.format(n)} از {fa.format(s.questions.length)}</small></span></button>; })}</nav><button className="change-scope" onClick={back}>تغییر دامنه</button></aside>
    <section className="question-stage"><div className="mobile-progress"><span>{item.s.title}</span><b>{fa.format(done)} / {fa.format(list.length)}</b><i><em style={{ width: `${progress}%` }} /></i></div><div className="q-meta"><span>{item.s.title}</span><b>پرسش {fa.format(index + 1)} از {fa.format(list.length)}</b></div><article className="question-card"><small className="q-code">{item.q.id}</small><h1>{item.q.prompt}</h1><div className="q-tags"><span>{item.q.required ? "پاسخ الزامی" : "پاسخ اختیاری"}</span></div><Field q={item.q} industries={industries} value={answers[item.q.id]} change={v => { setAnswers({ ...answers, [item.q.id]: v }); setError(""); }} />{error && <p className="error">{error}</p>}</article><div className="wizard-actions"><button onClick={() => index > 0 ? setIndex(index - 1) : back()}>سؤال قبل</button><button className="primary" onClick={next}>{index === list.length - 1 ? "مشاهده نتیجه" : "ثبت و ادامه"} ←</button></div></section></div></main>;
}

function AccountCapture({ industries, back, done }: { industries: string[]; back: () => void; done: () => void }) {
  const [form,setForm]=useState({name:"",email:"",password:"",phone:"",company:"",industry:""}),[error,setError]=useState(""),[submitting,setSubmitting]=useState(false);
  const valid=form.name.trim().length>2&&/^\S+@\S+\.\S+$/.test(form.email)&&form.password.length>=6&&form.phone.replace(/\D/g,"").length>=10;
  const submit=async()=>{setSubmitting(true);setError("");try{const register=await fetch("/api/auth/register",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(form)});if(!register.ok){if(register.status===409){const login=await fetch("/api/auth/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({email:form.email,password:form.password})});if(!login.ok)throw new Error("این ایمیل قبلاً عضو است؛ رمز حساب را درست وارد کنید.");}else throw new Error("ساخت حساب انجام نشد؛ اطلاعات را بررسی کنید.");}done();}catch(issue){setError(issue instanceof Error?issue.message:"خطایی رخ داد؛ دوباره تلاش کنید.");}finally{setSubmitting(false);}};
  return <main className="deep-account-page"><Header home={back}/><section className="deep-account-card"><div className="deep-account-identity"><img src="/brand/payamgostar-mark.png" alt=""/><span>یک قدم تا گزارش اختصاصی</span><h1>گزارش را در پنل خود نگه دارید.</h1><p>حساب شما با ایمیل ساخته می‌شود تا این گزارش و ارزیابی‌های بعدی همیشه در دسترس باشند.</p></div><div className="deep-account-form"><label><span>نام و نام خانوادگی *</span><input value={form.name} onChange={e=>setForm({...form,name:e.target.value})}/></label><label><span>ایمیل؛ نام کاربری *</span><input dir="ltr" type="email" value={form.email} onChange={e=>setForm({...form,email:e.target.value})}/></label><label><span>رمز عبور *</span><input dir="ltr" type="password" placeholder="حداقل ۶ کاراکتر" value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/></label><label><span>شماره موبایل *</span><input dir="ltr" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})}/></label><label><span>نام سازمان</span><input value={form.company} onChange={e=>setForm({...form,company:e.target.value})}/></label><label><span>صنعت</span><select value={form.industry} onChange={e=>setForm({...form,industry:e.target.value})}><option value="">انتخاب صنعت</option>{industries.map(item=><option key={item}>{item}</option>)}</select></label>{error&&<p>{error}</p>}<button disabled={!valid||submitting} onClick={submit}>{submitting?"در حال ساخت پنل…":"ساخت پنل و مشاهده گزارش ←"}</button><small>قبلاً عضو شده‌اید؟ همین ایمیل و رمز را وارد کنید تا گزارش به حساب موجود اضافه شود.</small></div></section></main>;
}

function calculate(sectionsSource:Section[],moduleCatalog:typeof modules,level: Level, selected: number[], answers: Answers, demo: boolean) {
  const questions = sectionsSource.filter(s => selected.includes(s.id)).flatMap(s => s.questions.filter(q => q.level <= level));
  const scores: number[] = [];
  for (const q of questions) { const v = answers[q.id], opts = optionsOf(q); if (!answered(v)) continue; if (typeof v === "string" && opts.length >= 4 && /(1 تا 5|۱ تا ۵|به‌ترتیب|سطوح پاسخ)/.test(q.scoreLogic)) { const i = Math.max(0, opts.indexOf(v)), normal = i / (opts.length - 1) * 100; scores.push(/5 برای|۵ برای/.test(q.scoreLogic) ? 100 - normal : normal); } }
  const count = questions.filter(q => answered(answers[q.id])).length, completion = demo ? 86 : Math.round(count / questions.length * 100), readiness = demo ? 78 : scores.length ? Math.round(scores.reduce((a, b) => a + b, 0) / scores.length) : Math.round(completion * .72);
  const corpus = [Object.values(answers).map(asText).join(" | "), ...selected.flatMap(id => sectionHints[id] || [])].join(" ");
  const userCount = Number(answers["2.3"] || 0), onPrem = /استقرار روی زیرساخت|تحت کنترل سازمان|On-Premise|سرور محلی/.test(corpus);
  let complexity = 18 + Math.max(0, selected.length - 3) * 7 + (userCount > 20 ? 10 : 0) + (userCount > 50 ? 14 : 0) + (userCount > 100 ? 14 : 0) + (selected.includes(5) ? 10 : 0) + (selected.includes(10) ? 8 : 0) + (onPrem ? 8 : 0); complexity = Math.min(96, complexity);
  const recommended = moduleCatalog.filter((m, i) => i === 0 || m.keys.some(k => corpus.includes(k))).slice(0, 8); for (const candidate of moduleCatalog.slice(1)) if (recommended.length < 4 && !recommended.includes(candidate)) recommended.push(candidate);
  const maxPlan = Math.max(...recommended.map(m => m.plan), 1), edition = onPrem ? "نسخه استاندارد (نصبی)" : maxPlan === 1 ? "ابری پایه" : maxPlan === 2 ? "ابری حرفه‌ای" : "ابری بی‌نهایت";
  return { total: questions.length, count, completion, readiness, complexity, recommended, edition, onPrem, userCount, status: readiness >= 75 ? "آماده ورود به طراحی راهکار" : readiness >= 50 ? "نیازمند هم‌راستاسازی پیش از اجرا" : "نیازمند آماده‌سازی پایه", timeline: complexity < 42 ? "۴ تا ۶ هفته" : complexity < 70 ? "۷ تا ۱۰ هفته" : "۱۱ تا ۱۶ هفته", tracking: `PG-${new Date().getFullYear()}-${level}${String(selected.length).padStart(2, "0")}${String(readiness).padStart(2, "0")}` };
}

function Ring({ value, label, dark = false }: { value: number; label: string; dark?: boolean }) { return <div className={`ring ${dark ? "dark" : ""}`} style={{ "--score": `${value * 3.6}deg` } as React.CSSProperties}><div><b>{fa.format(value)}</b><small>{label}</small></div></div>; }
function Results({ sectionsSource,moduleCatalog,outputTemplate,level, selected, answers, demo, restart }: { sectionsSource:Section[];moduleCatalog:typeof modules;outputTemplate?:CmsConfig["outputTemplates"][number];level: Level; selected: number[]; answers: Answers; demo: boolean; restart: () => void }) {
  const r = calculate(sectionsSource,moduleCatalog,level, selected, answers, demo); const [modal, setModal] = useState(false); const savedRef = useRef(false);
  useEffect(() => {
    if (demo || savedRef.current) return;
    savedRef.current = true;
    void fetch("/api/assessments", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ level, score: r.readiness, answers, result: r }) });
  // Persist once when the result screen is reached; the API associates the active customer session.
  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [demo, level]);
  return <main className="results"><Header home={restart} /><section className="result-hero"><div className="shell"><div><span>گزارش ارزیابی سطح {fa.format(level)}</span><h1>{r.status}</h1><p>براساس دامنه و پاسخ‌های ثبت‌شده، تصویر اولیه راهکار مناسب سازمان شما آماده است.</p><small>کد گزارش: <b>{r.tracking}</b></small></div><Ring value={r.readiness} label="امتیاز آمادگی" /></div></section><div className="result-body shell"><section className="result-cards"><article><span>نسخه پیشنهادی</span><h2>{r.edition}</h2><p>{r.onPrem ? "الزام کنترل زیرساخت یا محل نگهداری داده‌ها در پاسخ‌های شما دیده شده است." : "پلن پیشنهادی براساس دامنه ماژول‌ها، مقیاس و پیچیدگی نیازهای ثبت‌شده انتخاب شده است."}</p><div className="tags"><i>{r.onPrem ? "زیرساخت تحت کنترل سازمان" : "راه‌اندازی سریع‌تر"}</i><i>{r.userCount ? `${fa.format(r.userCount)} کاربر مورد انتظار` : "مقیاس قابل توسعه"}</i></div><a target="_blank" href={r.onPrem ? "https://www.payamgostar.com/fa/pricing/standard" : "https://www.payamgostar.com/fa/pricing/cloud"}>جزئیات رسمی این نسخه ←</a></article><article><span>کیفیت پیشنهاد</span><div className="confidence"><Ring value={r.completion} label="ضریب اطمینان" dark /><div><h3>{r.completion >= 80 ? "داده کافی برای تصمیم اولیه" : "نتیجه اولیه؛ قابل تکمیل"}</h3><p>{fa.format(r.count)} پاسخ از {fa.format(r.total)} سؤال ثبت شده است.</p></div></div></article></section>
    <section className="result-section"><div className="result-title"><div><span>سبد پیشنهادی</span><h2>ماژول‌های متناسب با نیاز شما</h2></div><p>پیشنهاد از قابلیت‌ها، مسائل و حوزه‌های انتخاب‌شده استخراج شده است.</p></div><div className="module-grid">{r.recommended.map((m, i) => <article key={m.name}><i>{fa.format(i + 1).padStart(2, "۰")}</i><div><h3>{m.name}</h3><p>{m.reason}</p></div><b>{m.plan === 1 ? "پایه" : m.plan === 2 ? "حرفه‌ای" : "پیشرفته"}</b></article>)}</div></section>
    {level >= 2 && <section className="deployment"><div><span>برآورد اولیه استقرار</span><b>{r.timeline}</b><p>پس از کنترل حجم داده، اتصال‌ها و منابع تیم داخلی نهایی می‌شود.</p></div><div>{["تحلیل دامنه و طراحی سناریو", "پیکربندی نسخه و ماژول‌ها", "آماده‌سازی و انتقال داده", "آموزش، پایلوت و بهره‌برداری"].map((x, i) => <article key={x}><b>{fa.format(i + 1)}</b><span>{x}</span></article>)}</div></section>}
    {level === 3 && <><section className="risk"><div><span>پروفایل پروژه</span><h2>ریسک و آمادگی در یک نگاه</h2><p>ترتیب اقدامات پیش از شروع پروژه را روشن می‌کند.</p></div><div>{[["آمادگی سازمانی", r.readiness, "good"], ["پیچیدگی اجرا", r.complexity, "warn"], ["کامل‌بودن داده", r.completion, "good"]].map(([label, value, cls]) => <article key={String(label)}><span><b>{label}</b><em>{fa.format(Number(value))}٪</em></span><i><u className={String(cls)} style={{ width: `${value}%` }} /></i></article>)}</div></section><section className="roadmap"><div className="result-title"><div><span>گذرنامه اجرا</span><h2>نقشه پیشنهادی ۳۰ / ۶۰ / ۹۰ روزه</h2></div></div><div>{[["۳۰", "هم‌راستاسازی", "تأیید دامنه، تیم پروژه، نقش‌ها و شاخص‌های موفقیت."], ["۶۰", "ساخت و پایلوت", "پیکربندی ماژول‌ها، اتصال‌ها و انتقال نمونه داده."], ["۹۰", "بهره‌برداری", "آموزش، کنترل پذیرش و آغاز پایش کیفیت استفاده."]].map(x => <article key={x[0]}><b>{x[0]}</b><span>روز</span><h3>{x[1]}</h3><p>{x[2]}</p></article>)}</div></section></>}
    <section className="proposal"><div><span>گام بعدی</span><h2>{outputTemplate?.title || "پروپوزال ویژه سازمان خود را دریافت کنید."}</h2><p>{outputTemplate?.summary || "خروجی برای کارشناس ارشد فروش ارسال می‌شود تا نسخه، ماژول‌ها و پیشنهاد تجاری نهایی شود."}</p></div><div>{outputTemplate?.proposalUrl&&outputTemplate.proposalUrl!=="#"?<a className="proposal-download" href={outputTemplate.proposalUrl}>{outputTemplate.proposalLabel||outputTemplate.primaryAction} ←</a>:<button onClick={() => setModal(true)}>{outputTemplate?.proposalLabel||outputTemplate?.primaryAction||"درخواست پروپوزال اختصاصی"} ←</button>}<button onClick={() => window.print()}>چاپ گزارش</button></div></section><div className="result-foot"><button onClick={restart}>شروع ارزیابی جدید</button><span>پیشنهاد نهایی پس از اعتبارسنجی تیم پیام‌گستر صادر می‌شود.</span></div></div>
    {modal && <div className="modal" onClick={() => setModal(false)}><div onClick={e => e.stopPropagation()}><button className="close" onClick={() => setModal(false)}>×</button><span>درخواست پروپوزال</span><h2>راه ارتباطی خود را ثبت کنید</h2><p>این بخش در نسخه نمایشی آماده اتصال به CRM پیام‌گستر است.</p><input placeholder="نام و نام خانوادگی" /><input placeholder="شماره تلفن همراه" /><input placeholder="نام سازمان" /><button onClick={() => setModal(false)}>ثبت درخواست آزمایشی</button><small>در این نسخه نمایشی اطلاعاتی ارسال نمی‌شود.</small></div></div>}
  </main>;
}

export default function AssessmentApp({ initialLevel, onExit,config }: { initialLevel?: Level; onExit?: () => void;config?:CmsConfig } = {}) {
  const sectionsSource=config?.questionnaire||questionnaireSections;
  const moduleCatalog=(config?.modules||modules) as unknown as typeof modules;
  const industries=[...(config?.industries||[])];
  const [view, setView] = useState<View>(initialLevel ? "scope" : "landing"), [level, setLevel] = useState<Level>(initialLevel || 1), [selected, setSelected] = useState<number[]>(coreSections), [answers, setAnswers] = useState<Answers>({}), [mode, setMode] = useState<"customer" | "expert">("customer"), [loaded, setLoaded] = useState(false), [hasDraft, setHasDraft] = useState(false), [demo, setDemo] = useState(false),[accountReady,setAccountReady]=useState(false);
  useEffect(()=>{fetch("/api/account").then(response=>setAccountReady(response.ok)).catch(()=>setAccountReady(false));},[]);
  useEffect(() => { if (initialLevel) { setLoaded(true); return; } try { const raw = localStorage.getItem(DRAFT_KEY); if (raw) { const d = JSON.parse(raw); if (d.answers && Object.keys(d.answers).length) { setHasDraft(true); setLevel(d.level || 1); setSelected(d.selected || coreSections); setAnswers(d.answers); setMode(d.mode || "customer"); } } } catch {} setLoaded(true); }, [initialLevel]);
  useEffect(() => { if (!loaded || demo) return; localStorage.setItem(DRAFT_KEY, JSON.stringify({ level, selected, answers, mode })); if (Object.keys(answers).length) setHasDraft(true); }, [loaded, demo, level, selected, answers, mode]);
  const home = () => { if (onExit) return onExit(); setView("landing"); setDemo(false); window.scrollTo(0, 0); };
  const choose = (l: Level) => { setLevel(l); setSelected(coreSections); setAnswers({}); setDemo(false); setView("scope"); window.scrollTo(0, 0); };
  const sample = () => { setLevel(3); setSelected([1,2,3,5,6,7,9,10,11]); setAnswers({ "2.3": 48, "3.2": "استفاده ابری بدون استقرار روی سرور سازمان", "2.10": ["مدیریت سرنخ‌ها و فرصت‌های فروش", "بازاریابی و مدیریت کمپین های تبلیغاتی", "ایجاد گردش کار و مدیریت فرایند", "پیگیری درخواست های مشتریان( ticketing)", "امکان ساخت گزارشات مدیریتی"] }); setDemo(true); setView("result"); window.scrollTo(0,0); };
  if (view === "scope") return <Scope sectionsSource={sectionsSource} level={level} selected={selected} setSelected={setSelected} mode={mode} setMode={setMode} back={home} start={() => { setView("wizard"); window.scrollTo(0,0); }} />;
  if (view === "wizard") return <Wizard sectionsSource={sectionsSource} industries={industries} level={level} selected={selected} answers={answers} setAnswers={setAnswers} back={() => { setView("scope"); window.scrollTo(0,0); }} finish={() => { setView(accountReady?"result":"account"); window.scrollTo(0,0); }} />;
  if (view === "account") return <AccountCapture industries={industries} back={()=>setView("wizard")} done={()=>{setAccountReady(true);setView("result");window.scrollTo(0,0);}}/>;
  if (view === "result") return <Results sectionsSource={sectionsSource} moduleCatalog={moduleCatalog} outputTemplate={config?.outputTemplates.find((item)=>item.level===level)} level={level} selected={selected} answers={answers} demo={demo} restart={home} />;
  return <Landing select={choose} sample={sample} hasDraft={hasDraft} resume={() => { setDemo(false); setView("wizard"); window.scrollTo(0,0); }} />;
}
