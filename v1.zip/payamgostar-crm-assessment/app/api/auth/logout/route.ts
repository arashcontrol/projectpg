import { accountCookie, logoutAccount } from "../../../../db/auth";

export async function POST(request: Request) {
  await logoutAccount(request).catch(() => undefined);
  return Response.json({ ok: true }, { headers: { "Set-Cookie": accountCookie("", 0) } });
}
