import { accountCookie, registerAccount } from "../../../../db/auth";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    if (!/^\S+@\S+\.\S+$/.test(String(body.email || ""))) return Response.json({ error: "invalid_email" }, { status: 400 });
    if (String(body.password || "").length < 6) return Response.json({ error: "weak_password" }, { status: 400 });
    if (String(body.name || "").trim().length < 3) return Response.json({ error: "invalid_name" }, { status: 400 });
    const result = await registerAccount(body);
    if ("conflict" in result) return Response.json({ error: "email_exists" }, { status: 409 });
    return Response.json({ ok: true, account: result.account }, { headers: { "Set-Cookie": accountCookie(result.token) } });
  } catch {
    return Response.json({ error: "registration_failed" }, { status: 500 });
  }
}
