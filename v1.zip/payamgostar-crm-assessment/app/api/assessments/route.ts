import { saveAssessment } from "../../../db/cms";
import { getAccountFromRequest } from "../../../db/auth";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    if (![0, 1, 2, 3].includes(body.level) || !body.answers || !body.result) {
      return Response.json({ error: "invalid_assessment" }, { status: 400 });
    }
    const account = await getAccountFromRequest(request).catch(() => null);
    const id = await saveAssessment({ ...body, accountId: account?.id });
    return Response.json({ ok: true, id });
  } catch {
    return Response.json({ ok: false, stored: false }, { status: 202 });
  }
}
