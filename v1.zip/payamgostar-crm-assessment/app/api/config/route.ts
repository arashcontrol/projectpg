import { getCmsConfig } from "../../../db/cms";

export async function GET() {
  const { config, source, meta } = await getCmsConfig();
  return Response.json({ config, source, meta }, { headers: { "Cache-Control": "no-store" } });
}
