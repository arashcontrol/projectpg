import { getAccountFromRequest } from "../../../db/auth";
import { getCmsConfig, listAccountAssessments, listAssessments } from "../../../db/cms";

export async function GET(request: Request) {
  try {
    const account = await getAccountFromRequest(request);
    if (!account) return Response.json({ error: "unauthorized" }, { status: 401 });
    const [reports, all, cms] = await Promise.all([listAccountAssessments(account.id), listAssessments(), getCmsConfig()]);
    const maturityScores = all.filter((item) => item.level === 0 && item.score !== null).map((item) => item.score as number);
    const distribution = [
      { label: "وضعیت بحرانی", min: 0, max: 24 }, { label: "نیازمند سامان‌دهی", min: 25, max: 49 },
      { label: "در مسیر بهبود", min: 50, max: 74 }, { label: "بلوغ مناسب", min: 75, max: 100 },
    ].map((band) => ({ ...band, count: maturityScores.filter((score) => score >= band.min && score <= band.max).length }));
    const latest = reports.find((item) => item.level === 0 && item.score !== null), lower = latest?.score === null || latest?.score === undefined ? 0 : maturityScores.filter((score) => score < latest.score!).length;
    return Response.json({ account: { id: account.id, email: account.email, fullName: account.fullName, companyName: account.companyName, industry: account.industry }, reports, benchmark: { total: maturityScores.length, distribution, percentile: maturityScores.length ? Math.round(lower / maturityScores.length * 100) : 0 }, club: cms.config.clubSettings });
  } catch { return Response.json({ error: "account_unavailable" }, { status: 500 }); }
}
