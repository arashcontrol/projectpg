import { getAdminFromRequest } from "../../../../db/auth";
import { getCmsConfig, saveCmsDocument } from "../../../../db/cms";
import { defaultCmsConfig, type CmsKey } from "../../../cms-config";

const keys = new Set(Object.keys(defaultCmsConfig));

async function adminUser(request:Request) {
  const user = await getAdminFromRequest(request);
  if (!user) return { error: Response.json({ error: "unauthorized" }, { status: 401 }) };
  return { user: { email:user.username,displayName:user.username } };
}

export async function GET(request:Request) {
  const auth = await adminUser(request);
  if ("error" in auth) return auth.error;
  const data = await getCmsConfig();
  return Response.json({ ...data, user: auth.user });
}

export async function PUT(request: Request) {
  const auth = await adminUser(request);
  if ("error" in auth) return auth.error;
  const body = await request.json();
  if (!keys.has(body.key)) return Response.json({ error: "invalid_key" }, { status: 400 });
  const saved = await saveCmsDocument(body.key as CmsKey, body.value, auth.user.email, body.summary);
  return Response.json({ ok: true, saved });
}
