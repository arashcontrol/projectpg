import { adminCookie, createAdminSession } from "../../../../db/auth";

export async function POST(request:Request){try{const body=await request.json(),result=await createAdminSession(String(body.username||""),String(body.password||""));if(!result)return Response.json({error:"invalid_credentials"},{status:401});return Response.json({ok:true},{headers:{"Set-Cookie":adminCookie(result.token)}});}catch{return Response.json({error:"login_failed"},{status:500});}}
