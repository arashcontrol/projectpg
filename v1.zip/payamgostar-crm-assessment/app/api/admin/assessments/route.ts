import { getAdminFromRequest } from "../../../../db/auth";
import { listAssessments } from "../../../../db/cms";

export async function GET(request:Request) {
  const user = await getAdminFromRequest(request);
  if (!user) return Response.json({ error: "unauthorized" }, { status: 401 });
  try {
    return Response.json({ items: await listAssessments() });
  } catch {
    return Response.json({ items: [] });
  }
}
