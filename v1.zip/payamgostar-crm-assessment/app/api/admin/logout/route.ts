import { adminCookie, logoutAdmin } from "../../../../db/auth";

export async function POST(request:Request){await logoutAdmin(request).catch(()=>undefined);return Response.json({ok:true},{headers:{"Set-Cookie":adminCookie("",0)}});}
