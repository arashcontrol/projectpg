CREATE TABLE `agent_events` (
	`id` text PRIMARY KEY NOT NULL,
	`event_type` text NOT NULL,
	`payload_json` text NOT NULL,
	`status` text DEFAULT 'queued' NOT NULL,
	`created_at` text NOT NULL,
	`processed_at` text
);
--> statement-breakpoint
CREATE TABLE `assessment_runs` (
	`id` text PRIMARY KEY NOT NULL,
	`level` integer NOT NULL,
	`status` text DEFAULT 'completed' NOT NULL,
	`score` integer,
	`contact_name` text,
	`contact_phone` text,
	`company_name` text,
	`industry` text,
	`answers_json` text NOT NULL,
	`result_json` text NOT NULL,
	`source` text DEFAULT 'website' NOT NULL,
	`created_at` text NOT NULL,
	`updated_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `audit_logs` (
	`id` text PRIMARY KEY NOT NULL,
	`actor_email` text NOT NULL,
	`action` text NOT NULL,
	`entity_type` text NOT NULL,
	`entity_id` text NOT NULL,
	`summary` text,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE `cms_documents` (
	`key` text PRIMARY KEY NOT NULL,
	`type` text NOT NULL,
	`data_json` text NOT NULL,
	`version` integer DEFAULT 1 NOT NULL,
	`updated_by` text NOT NULL,
	`updated_at` text NOT NULL
);
