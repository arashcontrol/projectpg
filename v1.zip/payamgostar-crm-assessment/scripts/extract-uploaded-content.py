#!/usr/bin/env python3
"""Build checked-in TypeScript seed data from the supplied business documents."""

from __future__ import annotations

import json
import re
from pathlib import Path

from docx import Document
from openpyxl import load_workbook


ROOT = Path(__file__).resolve().parents[1]
UPLOAD = Path("/workspace/scratch/eddd6c44b9c9/upload")
MATURITY_SOURCE = UPLOAD / "gamification ed5.1(1).xlsx"
FAQ_SOURCE = UPLOAD / "FAQ - Copy.docx"


def clean(value: object) -> str:
    text = "" if value is None else str(value)
    return re.sub(r"\s+", " ", text.replace("\u200c", "‌")).strip(" \n\r\t«»")


def write_ts(path: Path, prelude: str, name: str, data: object) -> None:
    payload = json.dumps(data, ensure_ascii=False, indent=2)
    path.write_text(f"{prelude}\nexport const {name} = {payload} as const;\n", encoding="utf-8")


def maturity_data() -> dict:
    wb = load_workbook(MATURITY_SOURCE, data_only=True)
    rows = list(wb["لیست سوالات جدید"].iter_rows(min_row=2, values_only=True))
    questions: list[dict] = []
    current: dict | None = None
    for number, question, label, option, score, topical in rows:
        if number is not None:
            current = {
                "id": int(number),
                "question": clean(question),
                "options": [],
            }
            questions.append(current)
        if current and option:
            topical_text = clean(topical)
            match = re.match(r"(.+?)\s*\+(\d+)$", topical_text)
            current["options"].append(
                {
                    "label": clean(label),
                    "text": clean(option),
                    "score": int(score or 0),
                    "topic": clean(match.group(1)) if match else "",
                    "topicWeight": int(match.group(2)) if match else 0,
                }
            )

    topic_rows = list(wb["موضوع سوالات"].iter_rows(min_row=2, values_only=True))
    axes = []
    topics = []
    for number, short, maturity, examined, module, *_ in topic_rows:
        if number is None:
            continue
        axes.append(
            {
                "questionId": int(number),
                "shortTitle": clean(short),
                "maturityAxis": clean(maturity),
                "examined": clean(examined),
                "module": clean(module),
            }
        )
        if module and clean(module) not in topics:
            topics.append(clean(module))

    bands = []
    for range_text, title, message in wb["پاسخ نمره بلوغ"].iter_rows(min_row=2, values_only=True):
        numbers = [int(x) for x in re.findall(r"\d+", str(range_text))]
        bands.append(
            {
                "min": numbers[0],
                "max": numbers[1],
                "title": clean(title),
                "message": clean(message),
            }
        )

    return {
        "source": MATURITY_SOURCE.name,
        "version": "5.1",
        "maxScore": 45,
        "estimatedMinutes": 7,
        "questions": questions,
        "axes": axes,
        "topics": topics,
        "bands": bands,
    }


def looks_like_question(text: str) -> bool:
    first = text.splitlines()[0].strip()
    return first.endswith(("؟", "?")) or "؟\n" in text or "?\n" in text


def faq_data() -> list[dict]:
    doc = Document(FAQ_SOURCE)
    categories: list[dict] = []
    category = {"id": "general", "title": "سوالات عمومی", "items": []}
    categories.append(category)
    pending: dict | None = None

    for paragraph in doc.paragraphs:
        raw = paragraph.text.strip()
        if not raw:
            continue
        lines = [clean(line) for line in raw.splitlines() if clean(line)]
        if not lines:
            continue
        normalized = "\n".join(lines)
        is_category = (
            len(lines) == 1
            and not looks_like_question(normalized)
            and (lines[0].endswith(":") or lines[0].startswith("سوالات "))
            and len(lines[0]) < 100
        )
        if is_category:
            title = lines[0].rstrip(":").strip()
            category = {
                "id": f"category-{len(categories) + 1}",
                "title": title,
                "items": [],
            }
            categories.append(category)
            pending = None
            continue

        if looks_like_question(normalized):
            question_end = next(
                (i for i, line in enumerate(lines) if line.endswith(("؟", "?"))),
                0,
            )
            question = " ".join(lines[: question_end + 1])
            answer = " ".join(lines[question_end + 1 :])
            pending = {
                "id": f"faq-{sum(len(c['items']) for c in categories) + 1}",
                "question": question,
                "answer": answer,
                "keywords": [],
            }
            category["items"].append(pending)
            continue

        if pending:
            pending["answer"] = clean(f"{pending['answer']} {normalized}")

    categories = [c for c in categories if c["items"]]
    for c in categories:
        for item in c["items"]:
            words = re.findall(r"[آ-یA-Za-z0-9‌]+", item["question"])
            stop = {"آیا", "چه", "چرا", "چگونه", "برای", "است", "در", "به", "از", "و", "یا", "می", "شود", "را"}
            item["keywords"] = [w for w in words if len(w) > 2 and w not in stop][:10]
    return categories


def main() -> None:
    write_ts(
        ROOT / "app" / "maturity-data.ts",
        "export type MaturityOption = { label: string; text: string; score: number; topic: string; topicWeight: number };\nexport type MaturityQuestion = { id: number; question: string; options: readonly MaturityOption[] };",
        "maturityAssessment",
        maturity_data(),
    )
    write_ts(
        ROOT / "app" / "faq-data.ts",
        "export type FaqItem = { id: string; question: string; answer: string; keywords: readonly string[] };\nexport type FaqCategory = { id: string; title: string; items: readonly FaqItem[] };",
        "faqCategories",
        faq_data(),
    )


if __name__ == "__main__":
    main()
