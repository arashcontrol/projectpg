import { desc, eq } from "drizzle-orm";
import { defaultCmsConfig, type CmsConfig, type CmsKey } from "../app/cms-config";
import { getDb } from "./index";
import { assessmentRuns, auditLogs, cmsDocuments } from "./schema";

export type CmsDocumentMeta = { key: string; type: string; version: number; updatedBy: string; updatedAt: string };

export async function getCmsConfig(): Promise<{ config: CmsConfig; source: "database" | "defaults"; meta: CmsDocumentMeta[] }> {
  try {
    const db = await getDb();
    const rows = await db.select().from(cmsDocuments);
    const config = { ...defaultCmsConfig } as CmsConfig;
    const meta: CmsDocumentMeta[] = [];
    for (const row of rows) {
      if (!(row.key in config)) continue;
      try {
        (config as unknown as Record<string, unknown>)[row.key] = JSON.parse(row.dataJson);
        meta.push({ key: row.key, type: row.type, version: row.version, updatedBy: row.updatedBy, updatedAt: row.updatedAt });
      } catch {
        // A malformed override never makes the public experience unavailable.
      }
    }
    return { config, source: rows.length ? "database" : "defaults", meta };
  } catch {
    return { config: defaultCmsConfig, source: "defaults", meta: [] };
  }
}

export async function saveCmsDocument(key: CmsKey, value: unknown, actorEmail: string, summary = "ویرایش از پنل مدیریت") {
  const db = await getDb();
  const now = new Date().toISOString();
  const existing = await db.select().from(cmsDocuments).where(eq(cmsDocuments.key, key)).limit(1);
  const version = (existing[0]?.version ?? 0) + 1;
  await db.insert(cmsDocuments).values({ key, type: key, dataJson: JSON.stringify(value), version, updatedBy: actorEmail, updatedAt: now }).onConflictDoUpdate({
    target: cmsDocuments.key,
    set: { dataJson: JSON.stringify(value), version, updatedBy: actorEmail, updatedAt: now },
  });
  await db.insert(auditLogs).values({
    id: crypto.randomUUID(), actorEmail, action: "cms.update", entityType: "cms_document", entityId: key, summary, createdAt: now,
  });
  return { key, version, updatedAt: now };
}

export async function saveAssessment(input: {
  level: number;
  score?: number;
  accountId?: string;
  contact?: { name?: string; email?: string; phone?: string; company?: string; industry?: string };
  answers: unknown;
  result: unknown;
}) {
  const now = new Date().toISOString();
  const id = `PG-${now.slice(0, 10).replaceAll("-", "")}-${crypto.randomUUID().slice(0, 8).toUpperCase()}`;
  const db = await getDb();
  await db.insert(assessmentRuns).values({
    id,
    level: input.level,
    score: input.score,
    contactName: input.contact?.name,
    contactPhone: input.contact?.phone,
    contactEmail: input.contact?.email,
    companyName: input.contact?.company,
    industry: input.contact?.industry,
    accountId: input.accountId,
    answersJson: JSON.stringify(input.answers),
    resultJson: JSON.stringify(input.result),
    createdAt: now,
    updatedAt: now,
  });
  return id;
}

export async function listAssessments() {
  const db = await getDb();
  return db.select().from(assessmentRuns).orderBy(desc(assessmentRuns.createdAt)).limit(200);
}

export async function listAccountAssessments(accountId: string) {
  const db = await getDb();
  return db.select().from(assessmentRuns).where(eq(assessmentRuns.accountId, accountId)).orderBy(desc(assessmentRuns.createdAt)).limit(100);
}
