import { integer, sqliteTable, text } from "drizzle-orm/sqlite-core";

export const cmsDocuments = sqliteTable("cms_documents", {
  key: text("key").primaryKey(),
  type: text("type").notNull(),
  dataJson: text("data_json").notNull(),
  version: integer("version").notNull().default(1),
  updatedBy: text("updated_by").notNull(),
  updatedAt: text("updated_at").notNull(),
});

export const assessmentRuns = sqliteTable("assessment_runs", {
  id: text("id").primaryKey(),
  level: integer("level").notNull(),
  status: text("status").notNull().default("completed"),
  score: integer("score"),
  contactName: text("contact_name"),
  contactPhone: text("contact_phone"),
  contactEmail: text("contact_email"),
  companyName: text("company_name"),
  industry: text("industry"),
  accountId: text("account_id"),
  answersJson: text("answers_json").notNull(),
  resultJson: text("result_json").notNull(),
  source: text("source").notNull().default("website"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
});

export const customerAccounts = sqliteTable("customer_accounts", {
  id: text("id").primaryKey(),
  email: text("email").notNull().unique(),
  passwordHash: text("password_hash").notNull(),
  passwordSalt: text("password_salt").notNull(),
  fullName: text("full_name").notNull(),
  phone: text("phone"),
  companyName: text("company_name"),
  industry: text("industry"),
  status: text("status").notNull().default("active"),
  createdAt: text("created_at").notNull(),
  updatedAt: text("updated_at").notNull(),
});

export const accountSessions = sqliteTable("account_sessions", {
  id: text("id").primaryKey(),
  accountId: text("account_id").notNull(),
  tokenHash: text("token_hash").notNull().unique(),
  expiresAt: text("expires_at").notNull(),
  createdAt: text("created_at").notNull(),
});

export const adminSessions = sqliteTable("admin_sessions", {
  id: text("id").primaryKey(),
  username: text("username").notNull(),
  tokenHash: text("token_hash").notNull().unique(),
  expiresAt: text("expires_at").notNull(),
  createdAt: text("created_at").notNull(),
});

export const auditLogs = sqliteTable("audit_logs", {
  id: text("id").primaryKey(),
  actorEmail: text("actor_email").notNull(),
  action: text("action").notNull(),
  entityType: text("entity_type").notNull(),
  entityId: text("entity_id").notNull(),
  summary: text("summary"),
  createdAt: text("created_at").notNull(),
});

export const agentEvents = sqliteTable("agent_events", {
  id: text("id").primaryKey(),
  eventType: text("event_type").notNull(),
  payloadJson: text("payload_json").notNull(),
  status: text("status").notNull().default("queued"),
  createdAt: text("created_at").notNull(),
  processedAt: text("processed_at"),
});
