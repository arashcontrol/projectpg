import { and, eq, gt } from "drizzle-orm";
import { getDb } from "./index";
import { accountSessions, adminSessions, customerAccounts } from "./schema";

const encoder = new TextEncoder();
const ACCOUNT_COOKIE = "pg_account_session";
const ADMIN_COOKIE = "pg_admin_session";

function hex(bytes: ArrayBuffer | Uint8Array) {
  return Array.from(bytes instanceof Uint8Array ? bytes : new Uint8Array(bytes)).map((value) => value.toString(16).padStart(2, "0")).join("");
}

function randomToken(size = 32) {
  const bytes = new Uint8Array(size);
  crypto.getRandomValues(bytes);
  return hex(bytes);
}

async function sha256(value: string) {
  return hex(await crypto.subtle.digest("SHA-256", encoder.encode(value)));
}

async function passwordHash(password: string, salt: string) {
  const key = await crypto.subtle.importKey("raw", encoder.encode(password), "PBKDF2", false, ["deriveBits"]);
  const bits = await crypto.subtle.deriveBits({ name: "PBKDF2", hash: "SHA-256", salt: encoder.encode(salt), iterations: 120_000 }, key, 256);
  return hex(bits);
}

export function readCookie(request: Request, name: string) {
  const cookie = request.headers.get("cookie") || "";
  const match = cookie.split(";").map((part) => part.trim()).find((part) => part.startsWith(`${name}=`));
  return match ? decodeURIComponent(match.slice(name.length + 1)) : null;
}

export function accountCookie(token: string, maxAge = 60 * 60 * 24 * 30) {
  return `${ACCOUNT_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}`;
}

export function adminCookie(token: string, maxAge = 60 * 60 * 12) {
  return `${ADMIN_COOKIE}=${encodeURIComponent(token)}; Path=/; HttpOnly; SameSite=Lax; Max-Age=${maxAge}`;
}

async function createAccountSession(accountId: string) {
  const db = await getDb(), token = randomToken(), now = new Date(), expires = new Date(now.getTime() + 30 * 86400_000);
  await db.insert(accountSessions).values({ id: crypto.randomUUID(), accountId, tokenHash: await sha256(token), expiresAt: expires.toISOString(), createdAt: now.toISOString() });
  return token;
}

export async function registerAccount(input: { email: string; password: string; name: string; phone?: string; company?: string; industry?: string }) {
  const db = await getDb(), email = input.email.trim().toLowerCase();
  const existing = await db.select({ id: customerAccounts.id }).from(customerAccounts).where(eq(customerAccounts.email, email)).limit(1);
  if (existing.length) return { conflict: true as const };
  const now = new Date().toISOString(), id = crypto.randomUUID(), salt = randomToken(16);
  await db.insert(customerAccounts).values({ id, email, passwordHash: await passwordHash(input.password, salt), passwordSalt: salt, fullName: input.name.trim(), phone: input.phone?.trim(), companyName: input.company?.trim(), industry: input.industry?.trim(), createdAt: now, updatedAt: now });
  return { account: { id, email, fullName: input.name.trim() }, token: await createAccountSession(id) };
}

export async function loginAccount(emailInput: string, password: string) {
  const db = await getDb(), email = emailInput.trim().toLowerCase();
  const rows = await db.select().from(customerAccounts).where(eq(customerAccounts.email, email)).limit(1), account = rows[0];
  if (!account || account.status !== "active" || await passwordHash(password, account.passwordSalt) !== account.passwordHash) return null;
  return { account, token: await createAccountSession(account.id) };
}

export async function getAccountFromRequest(request: Request) {
  const token = readCookie(request, ACCOUNT_COOKIE); if (!token) return null;
  const db = await getDb(), now = new Date().toISOString();
  const rows = await db.select({ account: customerAccounts }).from(accountSessions).innerJoin(customerAccounts, eq(accountSessions.accountId, customerAccounts.id)).where(and(eq(accountSessions.tokenHash, await sha256(token)), gt(accountSessions.expiresAt, now))).limit(1);
  return rows[0]?.account || null;
}

export async function logoutAccount(request: Request) {
  const token = readCookie(request, ACCOUNT_COOKIE); if (!token) return;
  const db = await getDb(); await db.delete(accountSessions).where(eq(accountSessions.tokenHash, await sha256(token)));
}

export async function createAdminSession(username: string, password: string) {
  const expectedUser = process.env.ADMIN_USERNAME || "admin", expectedPassword = process.env.ADMIN_PASSWORD || "admin";
  if (username !== expectedUser || password !== expectedPassword) return null;
  const db = await getDb(), token = randomToken(), now = new Date(), expires = new Date(now.getTime() + 12 * 3600_000);
  await db.insert(adminSessions).values({ id: crypto.randomUUID(), username, tokenHash: await sha256(token), expiresAt: expires.toISOString(), createdAt: now.toISOString() });
  return { username, token };
}

export async function getAdminFromRequest(request: Request) {
  const token = readCookie(request, ADMIN_COOKIE); if (!token) return null;
  const db = await getDb(), now = new Date().toISOString();
  const rows = await db.select().from(adminSessions).where(and(eq(adminSessions.tokenHash, await sha256(token)), gt(adminSessions.expiresAt, now))).limit(1);
  return rows[0] || null;
}

export async function logoutAdmin(request: Request) {
  const token = readCookie(request, ADMIN_COOKIE); if (!token) return;
  const db = await getDb(); await db.delete(adminSessions).where(eq(adminSessions.tokenHash, await sha256(token)));
}
